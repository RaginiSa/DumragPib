Installing the File Tranfer Daemon on the Raspberry Pi

Copy daemon files from the PC to the Raspberry Pi.
1) on PC start C:\SysGCC\Raspberry\TOOLS\PortableSmartty\SmarTTY.exe
2) In SmarTTY.exe menu, select SCP/Upload a Directory
3) In local directory put "\stembed2018\cg\lib\RaspberryPi\fileTransferDaemon", in Remote Directory put "/home/pi/fileTransferDaemon"
4) Click Upload

*************************************************************************************************************************
Installation:

Type the following command on the command line/terminal.
 1. cd /home/pi/fileTransferDaemon
 2. sudo python setup.py 


*************************************************************************************************************************
Starting/stopping the daemon :

1. To stop the daemon type:
   	sudo service altair_file_transfer stop

2. To Check status of daemon type:
	   sudo service altair_file_transfer status

3. To Restart the Daemon type:
	   sudo service altair_file_transfer restart
